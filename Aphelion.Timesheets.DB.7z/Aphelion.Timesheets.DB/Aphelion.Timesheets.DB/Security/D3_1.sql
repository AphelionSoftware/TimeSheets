﻿CREATE SCHEMA [D3]
    AUTHORIZATION [dbo];





